from limit_error import GroupLimitError


class Group:
    MAX_NUMBER_OF_STUDENTS = 10

    def __init__(self, number):
        self.number = number
        self.group = set()

    def add_student(self, student):
        if len(self.group) >= self.MAX_NUMBER_OF_STUDENTS:
            raise GroupLimitError(f"Too much students in this group")
        self.group.add(student)

    def delete_student(self, last_name):
        student = self.find_student(last_name)
        if student:
            self.group.remove(student)

    def find_student(self, last_name):
        for i in self.group:
            if i.last_name == last_name:
                return i
        return None

    def __str__(self):
        all_students = "\n".join(str(i) for i in self.group)
        return f"Number:{self.number}\n{all_students}"
